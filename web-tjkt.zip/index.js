const menuToogle = document.querySelector('.menuToogle input') 
const nav = document.querySelector('.header ul') 

menuToogle.addEventListener('click' , function () {
        nav.classList.toggle('slide')
} )
